const Path = {
  HOME: "/",
  LOGIN: "/login",
  SHOP: "/shop",
  home: "/home",
  CART: "/cart",
  WISHLIST: "/wishlist",
  REGISTER: "/register",
  USER: "/user",
  navbar: "/navbar",
  PRODUCT_DETAILS:"/product-details",
  CHECKOUT:"/checkout",
  CONTACT:"/contact",
  ORDER:"/order",
  BLOG:"/blog",
};
export default Path;
