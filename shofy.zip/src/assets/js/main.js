export const originPath = () => {
  const origin = window.location.origin;
  return origin
};
